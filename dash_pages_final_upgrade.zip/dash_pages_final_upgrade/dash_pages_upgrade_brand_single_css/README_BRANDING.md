
# Branding Add-On (Single CSS)

This pack upgrades your Dash Pages app with a single-file brand stylesheet and UI helpers.

## What's included
- `app/assets/styles/branding.css` — sets your purple (`#732282`) as Bootstrap primary, adds spacing utilities, KPI styles, and optional AG Grid accents.
- `app/component/navbar.py` — purple top navbar with a slot for a white/transparent logo (place at `app/assets/branding/logo-white.png`) and an auto-generated menu from Dash Pages.
- `app/component/page_scaffold.py` — reusable `page()` wrapper and `kpi_card()` for consistent layouts.
- `app/pages/style_guide.py` — visit **/style** to preview colours, buttons, KPIs, a chart, and a table.

## Apply
1. Copy these files into your project (preserving paths).
2. Ensure your app uses `dash_bootstrap_components` and `use_pages=True` in Dash.
3. Start your app and visit `/style` to verify brand styling.

## Optional: Plotly Template
If you'd like Plotly figures to default to your palette, add this during app creation:

```python
import plotly.io as pio
pio.templates["ho_theme"] = pio.templates["plotly_white"]
pio.templates["ho_theme"]["layout"]["colorway"] = [
    "#732282", "#00747A", "#002664", "#9C9A00", "#B06F00", "#882345"
]
pio.templates.default = "ho_theme"
```

This is optional — the CSS already styles Bootstrap and components (navbar, buttons, links).
