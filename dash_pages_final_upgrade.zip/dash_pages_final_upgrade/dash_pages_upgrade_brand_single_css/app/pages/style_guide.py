
# app/pages/style_guide.py
import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
import plotly.express as px
from app.component.page_scaffold import page, kpi_card
from dash import dash_table

dash.register_page(__name__, path="/style", name="Style", order=99)

# KPIs
kpis = dbc.Row(
    [
        kpi_card("Revenue", "£245k", "+8.2%", "up"),
        kpi_card("Churn", "2.1%", "-0.3pp", "down"),
        kpi_card("NPS", "47", "+2", "up"),
        kpi_card("Active Users", "12,430", "+4.4%", "up"),
    ],
    className="gx-3 gy-3"
)

# Chart
df = px.data.gapminder().query("year == 2007")
fig = px.scatter(df, x="gdpPercap", y="lifeExp", size="pop", color="continent",
                 hover_name="country", log_x=True, size_max=60)

# Table (DataTable; AG Grid optional)
table = dash_table.DataTable(
    columns=[{"name": c, "id": c} for c in ["country", "continent", "lifeExp", "gdpPercap"]],
    data=df[["country", "continent", "lifeExp", "gdpPercap"]].head(10).to_dict("records"),
    style_table={"overflowX": "auto"},
    style_cell={"padding": "6px", "fontSize": 14},
)

layout = page(
    "Brand Style Guide",
    "Preview of colours, components, KPIs, buttons, charts and tables.",
    [
        kpis,
        html.Hr(),
        dbc.ButtonGroup(
            [
                dbc.Button("Primary", color="primary"),
                dbc.Button("Outline", color="primary", outline=True),
                dbc.Button("Link", color="link"),
            ],
            className="mb-2"
        ),
        dbc.Row(
            [
                dbc.Col(dcc.Graph(figure=fig), md=8),
                dbc.Col(html.Div(table, className="card-ho p-2"), md=4),
            ],
            className="gx-3 gy-3"
        ),
    ]
)
