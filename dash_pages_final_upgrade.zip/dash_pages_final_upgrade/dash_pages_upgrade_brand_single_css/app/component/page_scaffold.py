
# app/component/page_scaffold.py
from dash import html
import dash_bootstrap_components as dbc

def kpi_card(label, value, delta=None, delta_dir=None, id=None):
    delta_el = None
    if delta is not None:
        cls = f"kpi-delta {'up' if delta_dir=='up' else 'down'}" if delta_dir in ('up','down') else "kpi-delta"
        delta_el = html.Div(delta, className=cls)
    return dbc.Col(
        html.Div(
            [html.Div(label, className="kpi-label"), html.Div(value, className="kpi-value"), delta_el],
            className="kpi-card"
        ),
        md=3, sm=6, xs=12, id=id
    )

def page(title, lead=None, children=None):
    return dbc.Container(
        [
            html.H2(title, className="mb-2"),
            html.P(lead, className="text-muted") if lead else None,
            html.Div(children or [])
        ],
        className="mt-4"
    )
