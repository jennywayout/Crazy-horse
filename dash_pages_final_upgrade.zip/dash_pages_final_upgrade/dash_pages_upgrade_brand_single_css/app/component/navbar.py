
# app/component/navbar.py
from dash import html
import dash_bootstrap_components as dbc
import dash

def _menu():
    pages = sorted(dash.page_registry.values(), key=lambda x: x.get("order", 999))
    return [dbc.NavItem(dbc.NavLink(p["name"], href=p["path"], active="exact")) for p in pages]

def _brand():
    # Slot for a white/transparent logo. Place your file at: app/assets/branding/logo-white.png
    # If you don't have a logo yet, the text fallback is used.
    img = html.Img(src="/assets/branding/logo-white.png", className="logo", alt="HO")
    return dbc.NavbarBrand([img, " ", "HO Operation Simulation"], href="/")

content = html.Div(
    dbc.Navbar(
        [
            _brand(),
            dbc.NavbarToggler(id="navbar-toggler", n_clicks=0),
            dbc.Collapse(dbc.Nav(_menu(), className="ms-auto", navbar=True), id="navbar-collapse", navbar=True),
        ],
        color="primary", dark=True, className="mb-2"
    )
)
