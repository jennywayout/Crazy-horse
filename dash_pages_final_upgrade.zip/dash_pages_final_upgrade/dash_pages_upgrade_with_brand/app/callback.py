# app/callback.py
"""Global callbacks (optional). Manual routing has been retired."""
from dash import callback, Input, Output, State

def register_callbacks(app):
    # Add any non-routing callbacks here, e.g. cross-page stores, theme toggles, etc.
    # Example placeholder (disabled):
    # @callback(Output('some-id','children'), Input('other-id','value'))
    # def _noop(value):
    #     return value
    return
