# app/component/footer.py
from dash import html
import dash_bootstrap_components as dbc

content = html.Footer(
    dbc.Container(
        html.Div(
            [
                html.Span("© "),
                html.Strong("HO / HOAI"),
                html.Span(" · Built with Dash Pages"),
            ],
            className="text-center py-3 text-muted",
        )
    ),
    className="mt-4",
)
