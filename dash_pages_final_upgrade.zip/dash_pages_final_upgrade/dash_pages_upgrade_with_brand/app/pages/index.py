# app/pages/index.py
import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
import plotly.express as px

dash.register_page(__name__, path="/", name="Index", order=0)

column1 = dbc.Col(
    [
        dcc.Markdown(
            "## Welcome\\nThis is your Home page rendered by **Dash Pages**."
        ),
        dcc.Link(dbc.Button("Go Home", color="secondary", outline=True), href="/"),
    ],
    md=4,
)

# Simple example figure (replace with your real content)
_df = px.data.gapminder().query("year == 2007")
fig = px.scatter(
    _df, x="gdpPercap", y="lifeExp", size="pop", color="continent",
    hover_name="country", log_x=True, size_max=60
)

column2 = dbc.Col([dcc.Graph(figure=fig)])

layout = dbc.Row([column1, column2], className="gx-4 gy-4")
