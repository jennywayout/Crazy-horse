# app/__init__.py
from flask import Flask
from dash import Dash, dcc, html
import dash
import dash_bootstrap_components as dbc
from dash_bootstrap_templates import load_figure_template

# Import your components — keep your module paths the same as your repo
from app.component import navbar, footer

def create_app():
    """Flask factory that mounts a Dash app using Dash Pages."""
    server = Flask(__name__)

    external_stylesheets = [dbc.themes.BOOTSTRAP, dbc.icons.BOOTSTRAP]
    load_figure_template("bootstrap")  # match Bootstrap styling in Plotly

    dash_app = Dash(
        __name__,
        server=server,
        url_base_pathname="/",      # host at root
        use_pages=True,               # ← Dash Pages ON
        external_stylesheets=external_stylesheets,
        suppress_callback_exceptions=True,
        meta_tags=[
            {"name": "viewport", "content": "width=device-width, initial-scale=1"}
        ],
        title="HO Operation Simulation",  # adjust if templated
    )

    # Keep your navbar/footer; swap the middle for Dash Pages' page_container
    dash_app.layout = html.Div(
        children=[
            dcc.Location(id="url", refresh=False),
            navbar.content,
            dbc.Container(dash.page_container, id="page-content", className="mt-4"),
            html.Hr(),
            footer.content,
        ]
    )

    # Optional: keep a callbacks module for global callbacks (no routing here)
    try:
        from app.callback import register_callbacks
        register_callbacks(dash_app)
    except Exception:
        # It's fine if you don't define any yet
        pass

    return server
