# app/component/navbar.py
from dash import html
import dash_bootstrap_components as dbc
import dash

def _menu():
    # Build nav items from the Dash Pages registry in `order` sequence
    pages = sorted(dash.page_registry.values(), key=lambda x: x.get("order", 999))
    items = [dbc.NavItem(dbc.NavLink(p["name"], href=p["path"], active="exact")) for p in pages]
    return items

content = html.Div(
    [
        dbc.NavbarSimple(
            children=_menu(),
            brand="HO Operation Simulation",
            brand_href="/",
            color="primary",
            dark=True,
            className="mb-2",
        )
    ]
)
