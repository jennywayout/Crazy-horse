# Dash Pages Upgrade Pack

This pack contains **drop-in replacements** and **new files** to migrate your current
single-page Dash app (with navbar/footer and manual `display_page` callback) to a
**multipage app using Dash Pages** — while keeping your Flask factory, Bootstrap
shell, and your existing navbar/footer components.

## What this pack includes

- `app/__init__.py` — creates the Flask server and mounts a Dash app with `use_pages=True`.
- `app/callback.py` — minimal placeholder for global callbacks (manual router removed).
- `app/component/navbar.py` — dynamic navbar built from the Dash Pages registry.
- `app/component/footer.py` — simple footer (feel free to keep your existing one).
- `app/pages/*.py` — each page registers itself with `dash.register_page(...)`.
- `assets/branding.css` — defines CSS variables for your HO palette.
- `run.py` — optional local entrypoint (`python run.py`).
- `requirements_upgrade.txt` — modernized baseline package versions (optional).

## How to apply

1. **Back up your repo / create a feature branch** (recommended).
2. Copy the contents of this pack over your existing project:
   - Replace your `app/__init__.py` with the one in this pack.
   - Replace or merge `app/component/navbar.py` and `footer.py` as needed.
   - Keep `app/pages/` filenames (index, predictions, insights, process) and update their content to match the `register_page` pattern shown here.
   - Keep `app/callback.py` only for truly global callbacks; remove any manual pathname → layout routing.
   - Add `assets/branding.css` if you don't already have it.
   - Optionally adopt versions in `requirements_upgrade.txt`.
3. Ensure your **Flask entry** still points to the factory:
   ```bash
   set FLASK_APP=run.py   # Windows (PowerShell: $env:FLASK_APP="run.py")
   flask run
   ```
   or simply:
   ```bash
   python run.py
   ```
4. Verify that navigation via your navbar now swaps pages automatically,
   without any routing callback.

## Notes

- Pages are **auto-discovered** under `app/pages/` because `Dash(..., use_pages=True)` is enabled.
- The navbar here is **dynamic**, reading from `dash.page_registry` so you don't need to hardcode menu items.
- Your palette is defined in CSS variables inside `assets/branding.css` to keep branding consistent across graphs and components.
- This upgrade aligns with the goals captured in your project specs (multi-page, local dev first, branding), and fits the current state as of 2025‑10‑23.
