# HO Dash App (Unified)
Multipage Plotly Dash app with Dash Pages, Flask factory, and HO brand styling.

## Quick start
```bash
python -m venv .venv && . .venv/bin/activate  # (Windows: .venv\Scripts\activate)
pip install -r requirements.txt
python run.py
# open http://127.0.0.1:8050
```
