import dash
from dash import html
from ..components.page_scaffold import page

dash.register_page(__name__, path="/process", name="Process")

layout = page("Process", html.P("Describe or visualize your data/process pipeline here."))
