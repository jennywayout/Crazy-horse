import dash
from dash import html
from ..components.page_scaffold import page

dash.register_page(__name__, path="/insights", name="Insights")

layout = page("Insights", html.P("Add tables/graphs with insights here."))
