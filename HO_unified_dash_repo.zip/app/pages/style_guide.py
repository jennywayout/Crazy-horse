import dash
from dash import html, dcc
import plotly.express as px

dash.register_page(__name__, path="/style", name="Style Guide")

fig = px.bar(x=["Teal","#00747A","Navy","#002664","Olive","#9C9A00","Amber","#B06F00","Crimson","#882345"],
             y=[1,2,3,4,3,2,1], title="Palette Preview")

layout = html.Div([
    html.H2("Style Guide"),
    html.P("Buttons, alerts, and cards use Bootstrap 'primary' mapped to HO purple."),
    html.Div([
        html.Button("Primary", className="btn btn-primary me-2"),
        html.Button("Secondary", className="btn btn-secondary me-2"),
        html.Button("Success", className="btn btn-success me-2"),
    ], className="mb-3"),
    dcc.Graph(figure=fig),
    html.Div("KPI sample classes are in assets/branding.css", className="mt-3")
])
