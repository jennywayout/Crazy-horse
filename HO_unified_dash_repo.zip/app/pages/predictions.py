import dash
from dash import html, dcc
import plotly.express as px
from ..components.page_scaffold import page

dash.register_page(__name__, path="/predictions", name="Predictions")

layout = page(
    "Predictions",
    html.P("Example chart placeholder:"),
    dcc.Graph(figure=px.line(x=[1,2,3], y=[2,1,4], title="Sample Forecast")),
)
