import dash
from dash import html
from ..components.page_scaffold import page, kpi_card

dash.register_page(__name__, path="/", name="Home")

layout = page(
    "Home",
    html.P("Welcome to the HO multipage Dash app."),
    html.Div([
        kpi_card("Active Users", "1,234"),
        kpi_card("Conversion", "3.7%"),
        kpi_card("Latency", "120 ms"),
    ], className="kpi-grid"),
)
