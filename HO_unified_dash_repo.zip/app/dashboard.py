import dash
from dash import html, dcc
import dash_bootstrap_components as dbc

from .components.navbar import make_navbar
from .components.footer import make_footer

def register_dashboard(server):
    external_stylesheets = [dbc.themes.BOOTSTRAP]
    app = dash.Dash(
        __name__,
        server=server,
        url_base_pathname="/",
        use_pages=True,
        external_stylesheets=external_stylesheets,
        suppress_callback_exceptions=True,
    )

    app.layout = dbc.Container(
        fluid=True,
        children=[
            make_navbar(),
            html.Main([dash.page_container], id="page-content", style={"padding":"1rem 0 2rem"}),
            make_footer(),
        ],
    )
    return app
