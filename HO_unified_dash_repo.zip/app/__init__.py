from flask import Flask
from .dashboard import register_dashboard

def create_app():
    app = Flask(__name__)
    register_dashboard(app)
    return app
