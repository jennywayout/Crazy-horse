from dash import html
import dash_bootstrap_components as dbc

def kpi_card(title, value, subtitle=None):
    return dbc.Card(
        dbc.CardBody([
            html.Div(title, className="kpi-title"),
            html.Div(value, className="kpi-value"),
            html.Small(subtitle, className="text-muted") if subtitle else None,
        ]),
        className="kpi-card",
    )

def page(title, *children):
    return html.Div([html.H2(title, className="page-title"), *children], className="page-wrapper")
