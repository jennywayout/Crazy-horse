from dash import html
import dash
import dash_bootstrap_components as dbc

BRAND_NAME = "HO Dash"

def _pages_sorted():
    pages = [p for p in dash.page_registry.values() if p.get("path") != "/404"]
    return sorted(pages, key=lambda p: p.get("name","").lower())

def make_navbar():
    dropdown_items = [
        dbc.DropdownMenuItem(p["name"], href=p["relative_path"])
        for p in _pages_sorted() if p.get("name")
    ]

    menu = dbc.DropdownMenu(
        label="Pages",
        children=dropdown_items,
        className="ms-2",
        color="primary",
        toggle_style={"color":"white"},
        caret=True,
        nav=True,
        in_navbar=True,
    )

    return dbc.Navbar(
        dbc.Container([
            dbc.NavbarBrand(BRAND_NAME, className="ms-2"),
            dbc.Nav([menu], navbar=True, className="ms-auto"),
        ], fluid=True),
        class_name="ho-navbar",
        color="primary",
        dark=True,
        sticky="top",
    )
