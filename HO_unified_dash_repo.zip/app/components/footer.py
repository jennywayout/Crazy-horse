from dash import html
from datetime import date

def make_footer():
    return html.Footer(
        html.Div(f"© {date.today().year} HO Operation Simulation — All rights reserved",
                 className="text-center py-3"),
        className="ho-footer mt-4",
        style={"borderTop":"1px solid rgba(0,0,0,0.1)"},
    )
